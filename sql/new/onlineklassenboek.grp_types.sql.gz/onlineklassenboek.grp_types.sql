-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2011 at 02:56 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7+squeeze1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ovckb`
--

--
-- Dumping data for table `grp_types`
--

INSERT INTO `grp_types` (`grp_type_id`, `grp_type_naam`, `grp_type_baas`, `grp_type_lid`, `grp_type_baas_mv`, `grp_type_baas_ev`, `grp_type_lid_mv`, `grp_type_lid_ev`, `grp_type_baas_type`, `grp_type_lid_type`) VALUES
(2, 'lesgroep', 'docent(en)', 'leerling(en)', 'docenten', 'docent', 'leerlingen', 'leerling', 'personeel', 'leerling'),
(4, 'ica-groep', 'begeleider(s)', 'leerling(en)', 'begeleiders', 'begeleider', 'leerlingen', 'leerling', 'personeel', 'leerling'),
(5, 'team', 'teamleider(s)', 'docent(en)', 'teamleiders', 'teamleider', 'docenten', 'docent', 'personeel', 'personeel'),
(6, 'sectie', 'sectievoorzitter(s)', 'docent(en)', 'sectievoorzitters', 'sectievoorzitter', 'docenten', 'docent', 'personeel', 'personeel'),
(7, 'gezin', 'ouder(s)/verzorger(s)', 'kind(eren)', 'ouders/verzorgers', 'ouder/verzorger', 'kinderen', 'kind', 'personeel', 'personeel');

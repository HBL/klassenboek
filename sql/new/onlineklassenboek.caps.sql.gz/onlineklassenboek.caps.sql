-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2011 at 02:57 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7+squeeze1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ovckb`
--

--
-- Dumping data for table `caps`
--

INSERT INTO `caps` (`cap_id`, `name`, `comment`) VALUES
(1, 'GRANT', ''),
(2, 'SU', ''),
(3, 'REVOKE', ''),
(4, 'STATS', ''),
(5, 'AANMAAKCODES_DOC', ''),
(6, 'ADD_DOC2GRP2VAK', ''),
(7, 'DEL_DOC2GRP2VAK', ''),
(8, 'ADD_GRP', ''),
(9, 'MOD_GRP', ''),
(10, 'PPL2GRP_OWN', 'personen toevoegen aan en verwijderen uit eigen groepen'),
(11, 'PPL2CAPS_SELF', 'capabilities van jezelf aan anderen geven en capabilities die je zelf hebt gegeven weer intrekken'),
(12, 'NEW_PPL', '');

-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2011 at 02:58 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7+squeeze1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ovckb`
--

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`tag_id`, `tag`) VALUES
(1, 'repetitie'),
(2, 'so'),
(3, 'inleveren'),
(4, 'in de les'),
(5, 'maken'),
(6, 'nakijken'),
(7, 'leren'),
(9, 'vt'),
(10, 'st'),
(11, 'afspraak'),
(12, 'afspraak voldaan'),
(13, 'afspraak niet voldaan'),
(14, 'repetitie gemist'),
(15, 'briefje inleveren'),
(16, 'briefje ingeleverd'),
(17, 'hw gemaakt'),
(18, 'hw niet gemaakt'),
(19, 'so gemist'),
(20, 'hw niet in orde'),
(21, 'per1'),
(22, 'per2'),
(23, 'per3');

-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2011 at 02:55 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7+squeeze1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ovckb`
--
CREATE DATABASE `ovckb` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `ovckb`;

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `replaceby_tag_id` int(11) DEFAULT NULL,
  `new_tag_id` int(11) DEFAULT NULL,
  `action_name` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `agenda`
--

CREATE TABLE IF NOT EXISTS `agenda` (
  `agenda_id` int(11) NOT NULL AUTO_INCREMENT,
  `schooljaar` enum('0809','0910','1011','1112') COLLATE utf8_bin NOT NULL,
  `week` tinyint(4) NOT NULL,
  `dag` tinyint(4) NOT NULL,
  `lesuur` varchar(4) COLLATE utf8_bin NOT NULL,
  `notitie_id` int(11) NOT NULL,
  PRIMARY KEY (`agenda_id`),
  UNIQUE KEY `notitie_id` (`notitie_id`),
  KEY `schooljaar` (`schooljaar`,`week`),
  KEY `schooljaar_2` (`schooljaar`,`week`,`dag`,`lesuur`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=19526 ;

-- --------------------------------------------------------

--
-- Table structure for table `caps`
--

CREATE TABLE IF NOT EXISTS `caps` (
  `cap_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`cap_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `cijfers`
--

CREATE TABLE IF NOT EXISTS `cijfers` (
  `notitie_id` int(11) NOT NULL,
  `ppl_id` int(11) NOT NULL,
  `cijfer` decimal(3,1) DEFAULT NULL,
  PRIMARY KEY (`notitie_id`,`ppl_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `customorder`
--

CREATE TABLE IF NOT EXISTS `customorder` (
  `doc_ppl_id` int(11) NOT NULL,
  `ppl_id` int(11) NOT NULL,
  `grp2vak_id` int(11) NOT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`doc_ppl_id`,`ppl_id`,`grp2vak_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `doc2grp2vak`
--

CREATE TABLE IF NOT EXISTS `doc2grp2vak` (
  `ppl_id` int(11) NOT NULL,
  `grp2vak_id` int(11) NOT NULL,
  PRIMARY KEY (`ppl_id`,`grp2vak_id`),
  KEY `ppl_id` (`ppl_id`),
  KEY `grp2vak_id` (`grp2vak_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_sha1` varchar(40) COLLATE utf8_bin NOT NULL,
  `file_naam` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file_mimetype` varchar(128) COLLATE utf8_bin NOT NULL,
  `file_size` int(11) NOT NULL,
  `ppl_id` int(11) NOT NULL,
  `busy` tinyint(1) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `downloaded` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `file_naam` (`file_naam`,`ppl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=57 ;

-- --------------------------------------------------------

--
-- Table structure for table `grp`
--

CREATE TABLE IF NOT EXISTS `grp` (
  `grp_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `schooljaar` enum('0809','0910','1011','1112') COLLATE utf8_bin NOT NULL,
  `stamklas` tinyint(1) NOT NULL DEFAULT '0',
  `grp_type_id` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`grp_id`),
  UNIQUE KEY `naam` (`naam`,`schooljaar`,`grp_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1126 ;

-- --------------------------------------------------------

--
-- Table structure for table `grp2grp`
--

CREATE TABLE IF NOT EXISTS `grp2grp` (
  `child_grp_id` int(11) NOT NULL,
  `parent_grp_id` int(11) NOT NULL,
  PRIMARY KEY (`child_grp_id`,`parent_grp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `grp2vak`
--

CREATE TABLE IF NOT EXISTS `grp2vak` (
  `grp2vak_id` int(11) NOT NULL AUTO_INCREMENT,
  `grp_id` int(11) NOT NULL,
  `vak_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`grp2vak_id`),
  UNIQUE KEY `grp_id` (`grp_id`,`vak_id`),
  KEY `vak_id` (`vak_id`),
  KEY `grp_id_2` (`grp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3834 ;

-- --------------------------------------------------------

--
-- Table structure for table `grp2vak2agenda`
--

CREATE TABLE IF NOT EXISTS `grp2vak2agenda` (
  `grp2vak_id` int(11) NOT NULL,
  `agenda_id` int(11) NOT NULL,
  PRIMARY KEY (`grp2vak_id`,`agenda_id`),
  KEY `grp_id` (`grp2vak_id`),
  KEY `agenda_id` (`agenda_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `grp2vak2vaksite`
--

CREATE TABLE IF NOT EXISTS `grp2vak2vaksite` (
  `grp2vak_id` int(11) NOT NULL,
  `vaksite_id` int(11) NOT NULL,
  PRIMARY KEY (`grp2vak_id`,`vaksite_id`),
  UNIQUE KEY `grp2vak_id` (`grp2vak_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `grp_bak`
--

CREATE TABLE IF NOT EXISTS `grp_bak` (
  `grp_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `schooljaar` enum('0809','0910','1011','1112') COLLATE utf8_bin NOT NULL,
  `stamklas` tinyint(1) NOT NULL DEFAULT '0',
  `grp_type_id` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`grp_id`),
  UNIQUE KEY `naam` (`naam`,`schooljaar`,`grp_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=908 ;

-- --------------------------------------------------------

--
-- Table structure for table `grp_types`
--

CREATE TABLE IF NOT EXISTS `grp_types` (
  `grp_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `grp_type_naam` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_baas` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_lid` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_baas_mv` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_baas_ev` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_lid_mv` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_lid_ev` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `grp_type_baas_type` enum('leerling','personeel','ouder') COLLATE utf8_bin NOT NULL,
  `grp_type_lid_type` enum('leerling','personeel','ouder') COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`grp_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(32) COLLATE utf8_bin NOT NULL,
  `orig_ppl_id` int(11) DEFAULT NULL,
  `ppl_id` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(15) COLLATE utf8_bin NOT NULL,
  `comment` text COLLATE utf8_bin,
  PRIMARY KEY (`log_id`),
  KEY `event` (`event`),
  KEY `ppl_id` (`ppl_id`),
  KEY `evppl` (`event`,`ppl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=97757 ;

-- --------------------------------------------------------

--
-- Table structure for table `lokalen`
--

CREATE TABLE IF NOT EXISTS `lokalen` (
  `lokaal_id` int(11) NOT NULL,
  `lokaal_naam` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`lokaal_id`),
  UNIQUE KEY `lokaal_naam` (`lokaal_naam`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `notities`
--

CREATE TABLE IF NOT EXISTS `notities` (
  `notitie_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `creat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`notitie_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=19753 ;

-- --------------------------------------------------------

--
-- Table structure for table `notities2teletop`
--

CREATE TABLE IF NOT EXISTS `notities2teletop` (
  `notitie_id` int(11) NOT NULL,
  `vaksite_id` int(11) NOT NULL,
  `doc_id` varchar(32) COLLATE utf8_bin NOT NULL,
  `col` enum('col1','col2','col3','col4') COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`notitie_id`),
  UNIQUE KEY `notitie_id` (`notitie_id`,`vaksite_id`,`doc_id`),
  KEY `vaksite_id` (`vaksite_id`,`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ppl`
--

CREATE TABLE IF NOT EXISTS `ppl` (
  `ppl_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam1` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `naam2` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `naam0` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `login` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'escaped with htmlspecialchars',
  `active` tinyint(1) DEFAULT '0' COMMENT '0 is active and NULL is inactive',
  `password` varchar(41) COLLATE utf8_bin DEFAULT NULL,
  `pw_reset_count` int(11) NOT NULL DEFAULT '0',
  `email` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT 'escaped with htmlspecialchars',
  `oldid` int(11) DEFAULT NULL COMMENT 'tmp',
  `type` enum('leerling','personeel','ouder') CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `timeout` int(11) NOT NULL DEFAULT '60',
  `nieuwsbrief` tinyint(1) NOT NULL DEFAULT '0',
  `quotum` int(11) NOT NULL DEFAULT '104857600',
  `maxupload` int(11) NOT NULL DEFAULT '3145728',
  PRIMARY KEY (`ppl_id`),
  UNIQUE KEY `login` (`login`,`active`),
  KEY `ppl_id` (`ppl_id`,`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5137 ;

-- --------------------------------------------------------

--
-- Table structure for table `ppl2agenda`
--

CREATE TABLE IF NOT EXISTS `ppl2agenda` (
  `ppl_id` int(11) NOT NULL,
  `agenda_id` int(11) NOT NULL,
  `allow_edit` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ppl_id`,`agenda_id`),
  KEY `ppl_id` (`ppl_id`),
  KEY `agenda_id` (`agenda_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ppl2caps`
--

CREATE TABLE IF NOT EXISTS `ppl2caps` (
  `ppl_id` int(11) NOT NULL,
  `cap_id` int(11) NOT NULL,
  `granter_ppl_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ppl_id`,`cap_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ppl2grp`
--

CREATE TABLE IF NOT EXISTS `ppl2grp` (
  `ppl_id` int(11) NOT NULL,
  `grp_id` int(11) NOT NULL,
  PRIMARY KEY (`ppl_id`,`grp_id`),
  KEY `ppl_id` (`ppl_id`),
  KEY `grp_id` (`grp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ppl2phpsessid`
--

CREATE TABLE IF NOT EXISTS `ppl2phpsessid` (
  `ppl_id` int(11) NOT NULL,
  `phpsessid` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`ppl_id`,`phpsessid`),
  KEY `ppl_id` (`ppl_id`),
  KEY `phpsessid` (`phpsessid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ppl2teletop`
--

CREATE TABLE IF NOT EXISTS `ppl2teletop` (
  `ppl_id` int(11) NOT NULL,
  `teletop_username` varchar(32) COLLATE utf8_bin NOT NULL,
  `teletop_password` tinyblob NOT NULL,
  PRIMARY KEY (`ppl_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=24 ;

-- --------------------------------------------------------

--
-- Table structure for table `tags2actions`
--

CREATE TABLE IF NOT EXISTS `tags2actions` (
  `tag_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  PRIMARY KEY (`tag_id`,`action_id`),
  KEY `tag_id` (`tag_id`),
  KEY `action_id` (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tags2notities`
--

CREATE TABLE IF NOT EXISTS `tags2notities` (
  `tag_id` int(11) NOT NULL,
  `notitie_id` int(11) NOT NULL,
  PRIMARY KEY (`tag_id`,`notitie_id`),
  KEY `tag_id` (`tag_id`),
  KEY `notitie_id` (`notitie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `vak`
--

CREATE TABLE IF NOT EXISTS `vak` (
  `vak_id` int(11) NOT NULL AUTO_INCREMENT,
  `afkorting` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `naam` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`vak_id`),
  UNIQUE KEY `afkorting` (`afkorting`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=103 ;

-- --------------------------------------------------------

--
-- Table structure for table `vaksites`
--

CREATE TABLE IF NOT EXISTS `vaksites` (
  `vaksite_id` int(11) NOT NULL AUTO_INCREMENT,
  `vaksite` varchar(128) COLLATE utf8_bin NOT NULL,
  `vaksite_naam` varchar(64) COLLATE utf8_bin NOT NULL,
  `vermeld_vak` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vaksite_id`),
  UNIQUE KEY `vaksite` (`vaksite`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=35 ;

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `KB_LGRP`(
grp VARCHAR( 16 ) ,
vak VARCHAR( 8 )
) RETURNS varchar(25) CHARSET utf8
    DETERMINISTIC
BEGIN RETURN IF(vak IS NULL, grp, IF( grp REGEXP vak, grp, CONCAT( grp, '/', vak ) ) ); END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `KB_LINK`(
target VARCHAR( 32 ) ,
notitie_id INT( 11 ),
dag INT ( 1 ),
lesuur INT ( 1 ),
additional VARCHAR( 256 ),
text VARCHAR( 32 )
) RETURNS varchar(512) CHARSET utf8
    DETERMINISTIC
BEGIN RETURN CONCAT('<a style="text-decoration: none" href="', target, '?notitie_id=', notitie_id, '&dag=', dag, '&lesuur=', lesuur, additional, '">', text, '</a>'); END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `KB_NAAM`(
naam0 VARCHAR( 128 ) ,
naam1 VARCHAR( 64 ) ,
naam2 VARCHAR( 16 )
) RETURNS varchar(190) CHARSET utf8
    DETERMINISTIC
BEGIN RETURN CONCAT( naam1, ' ', TRIM( LEADING ' ' FROM CONCAT( naam2, ' ', naam0 ) ) ); END$$

DELIMITER ;
